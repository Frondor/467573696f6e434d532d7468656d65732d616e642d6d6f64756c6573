<?php

class Postback_rentabiliweb extends MX_Controller 
{
	private $fields = array();
	
	const STATUS_SUCCESS = 1;
	const STATUS_ERROR   = 2;
	
	public function __construct()
	{
		parent::__construct();
		
		$this->load->config('rentabiliweb');
	}
	
	public function index()
	{
		$this->fields['docId']	= (int)$this->input->get('docId');
		$this->fields['uid']	  = (int)$this->input->get('uid');
		$this->fields['awards']   = (int)$this->input->get('awards');
		$this->fields['trId']	 = $this->input->get('trId');
		$this->fields['promoId']  = $this->input->get('promoId') ? (int)$this->input->get('promoId') : 0 ;
		$this->fields['hash']	 = $this->input->get('hash');
		$this->fields['time']     = time();
		$this->fields['status']   = 0;
		$this->fields['message']  = '';
		
		// Check the get variables
		if (!$this->input->get('uid') || !$this->input->get('awards') || !$this->input->get('trId') || !$this->input->get('hash'))
		{
			die('KO - No parameters ware passed!');
		}
		
		// Start by verifying the request
		if (md5($this->fields['uid'] . $this->fields['awards'] . $this->fields['trId'] . $this->config->item('hash_key')) != $this->fields['hash'])
		{
			// Hash error
			$this->InsertLog('Invalid request, the hash did not match.', self::STATUS_ERROR);
			die('KO - 1');
		}
		
		// Check if the request was already processed
		if ($this->IsProcessed())
		{
			# this transaction reference was already processed
			die('KO - 2');
		}
		
		// Verify the user id
		if (!$this->IsValidUser())
		{
			// The user id specified is invalid
			$this->InsertLog('Invalid user id, the specified user does not exist.', self::STATUS_ERROR);
			die('KO - The user id is invalid.');
		}
		
		$this->db->query("UPDATE `account_data` SET `dp` = `dp` + ? WHERE `id` = ? LIMIT 1;", array($this->fields['awards'], $this->fields['uid']));

		$this->InsertLog('Successful transaction.', self::STATUS_SUCCESS);

		die('OK');
	}
	
	private function InsertLog($message, $status)
	{
		$this->fields['message'] = $message;
		$this->fields['status'] = $status;
		
		$this->db->insert("rentabiliweb_logs", $this->fields);
	}
	
	private function IsProcessed()
	{
		$query = $this->db->query("SELECT `id` FROM `rentabiliweb_logs` WHERE `trId` = ? AND `status` = ?;", array($this->fields['trId'], self::STATUS_SUCCESS));
		
		if ($query && $query->num_rows() > 0)
		{
			// Already processed
			return true;
		}
		
		return false;
	}
	
	private function IsValidUser()
	{
		$query = $this->db->query("SELECT `id` FROM `account_data` WHERE `id` = ?;", array($this->fields['uid']));
		
		if ($query && $query->num_rows() > 0)
		{
			// User exists
			return true;
		}
		
		return false;
	}
}
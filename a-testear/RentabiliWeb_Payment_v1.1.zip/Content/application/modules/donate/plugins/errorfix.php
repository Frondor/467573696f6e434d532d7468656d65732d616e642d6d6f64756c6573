<?php

class Errorfix extends MX_Controller
{
	public function __construct()
	{
	}
}
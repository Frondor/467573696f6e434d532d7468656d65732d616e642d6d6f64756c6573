#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi

 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive usually on the desktop.

 2. Copy the contents of the folder "Content" into the root folder of your copy of FusionCMS 
    (Example: "/var/www/public_html" or "C:/xampp/htdocs").
    2. Do not delete the old donate module, we need to merge this one with the old one.

 3. Open the folder SQL from the extracted files from the module archive and import the sql file into your FusionCMS database.

 4. Navigate to "User groups & permissions" on the Admin Panel side menu.

 5. Give your groups permissions to the RentabiliWeb ACP Logs page.
    5. Click "Groups".
    5. Select your group usually "Owner" and click the pencil button (Edit).
    5. Locate the section "Roles (?)".
    5. Locate "RentabiliWeb Admin" in that secontion and thick the permission (administrate).

 6. Register new account at the RentabiliWeb website (http://www.rentabiliweb.com/).
 
 7. Create new "Virtual Currency" Document/Application.
    7. Once you are logged in, on the left side menu locate the section "Virtual Currency". (This is in English)
    7. Click "Document management".
    7. On this page there will be a big button "Create a document" click it.
    7. Select "Virtual currency".
    7. Fill in the fields.
    7. For "Call back URL" enter: http://your-website/donate/postback_rentabiliweb
    7. For "Callback security HASH KEY" enter something long and very random,
       what i did was generate a sha1 hash at http://www.sha1-online.com/.
    7. Once everything is filled in, save it by clicking "Validate" at the bottom of the page.
    7. You will be redirected to another page with the link "=> To install the scripts, click here !"
       click on it.
    7. At this page you will find "Technical information" that you need to configure the module.

 8. Configurate the module.
    8. Go to the FusionCMS Admin Panel Dashboard.
    8. In the section "Installed modules" locate the module "Donate panel" and click "Edit configs".
    8. Scroll down to the section "rentabiliweb.php".
    8. Fill in the fields "Document id", "Website id" and "Hash key" with the values you got from step 7.

 6. You are done.

CREATE TABLE IF NOT EXISTS `rentabiliweb_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `docId` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `awards` int(10) NOT NULL DEFAULT '0',
  `trId` varchar(255) NOT NULL,
  `promoId` int(10) NOT NULL DEFAULT '0',
  `hash` varchar(255) NOT NULL,
  `status` int(1) DEFAULT '0',
  `message` text,
  `time` int(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi
 
 ! This plugin does not support SummitEmu.
 
 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive usually on the desktop.

 2. Copy the contents of the folder Content into the root folder of your copy of FusionCMS, merge and replace all.
 
 3. Open the folder SQL from the extracted files from the module archive,
    in this folder you will find the data required for deferrent versions of wow, 
    choose the ones your realms run on and import them into the Fusion Database.
    Note: You can import all of them if you're not sure which ones you need.

 4. Clear the FusionCMS cache folders.

 5. Clear your browser cache. 

 6. You are done.

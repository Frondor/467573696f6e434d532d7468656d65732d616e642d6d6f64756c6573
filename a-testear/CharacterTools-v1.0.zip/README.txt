#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi
 
 ! This plugin does not support SummitEmu.
 
 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive usually on the desktop.

 2. Copy the contents of the folder Content into the root folder of your copy of FusionCMS, merge and replace all.
 
 3. Open the folder SQL from the extracted files from the module archive, and import the sql file into your FusionCMS database.

 4. You are done.

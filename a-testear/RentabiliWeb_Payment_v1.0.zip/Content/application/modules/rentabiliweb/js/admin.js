var Donate = {
	
	search: function()
	{
		var string = $("#search").val();
		
		if (string.length == 0)
		{
			window.location = window.location;
		}
		
		var process = function()
		{
			$("#donate_list").html('<center><img src="' + Config.URL + 'application/themes/admin/images/ajax.gif" /><br /><br /></center>');
			
			$.post(Config.URL + "rentabiliweb/admin/search/", {string: string, csrf_token_name: Config.CSRF}, function(data)
			{
				$("#donate_list").fadeOut(150, function()
				{
					$(this).html(data).slideDown(500, function()
					{
						Tooltip.refresh();
					});
				});
			});
		};
		
		if (typeof $('#pagination') != 'undefined' && $('#pagination').length > 0)
		{
			$('#pagination').parent().fadeOut('fast', process);
		}
		else
		{
			process();
		}
	},

	give: function(id, field)
	{
		$(field).parents("tr").children("td:nth-child(3)").css({"text-decoration":"none"});
		$(field).parents("tr").children("td:nth-child(4)").css({"color":"inherit", "cursor":"default"}).html("Manually compl.");

		$(field).parent().remove();

		$.get(Config.URL + "rentabiliweb/admin/give/" + id, function(data)
		{
			console.log(data);
		});
	}
};
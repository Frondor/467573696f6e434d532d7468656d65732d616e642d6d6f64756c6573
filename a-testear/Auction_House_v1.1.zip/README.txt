#### IMPORTANT ####

 ! This Plugin has been written by ChoMPi
 
 ! This plugin does not support SummitEmu.
 
 ! If you wish to contact me for work please send me an E-Mail with title "(Work) <your title>" to email address: chompibg@gmail.com
   or try finding me on skype: chikina6335
 
#### INSTALLATION ####

 1. Extract the contents of the archive usually on the desktop.

 2. Copy the contents of the folder Content into the root folder of your copy of FusionCMS.
 
 3. Go to the Admin Panel -> Menu Links.
    3. Click the "Create link" button.
    3. Step 1. Enter title for the link (Auction House etc...)
    3. Step 2. Enter URL like so: auctionhouse
    3. step 3. Select one of the two possible menus Top or Side and submit.

 4. Navigate to "User groups & permissions" on the Admin Panel side menu.

 5. Give your groups permissions to the Auction House Module ACP Page.
    5. Click "Groups".
    5. Select your group usually "Owner" and click the pencil button (Edit).
    5. Locate the section "Roles (?)".
    5. Locate "Auction House Viewer" in that secontion and thick the two permissions (view and administrate).

 6. If you are using any emulator other than Mangos, do the following:
    6. On the ACP side menu you will see Auction House if you have given yourself permissions successfully, click it.
    6. Now simply click the button "Run the scanner!".

 6. You are done.

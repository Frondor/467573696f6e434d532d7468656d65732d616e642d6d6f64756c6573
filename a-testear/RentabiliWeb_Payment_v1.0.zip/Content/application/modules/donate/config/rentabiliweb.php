<?php

/*
|--------------------------------------------------------------------------
| General settings
|--------------------------------------------------------------------------
*/

$config['enabled'] = 'true';
$config['button_text'] = 'RentabiliWeb';
$config['rw_iframe_width'] = '705';
$config['rw_iframe_height'] = '520';
$config['document_id'] = '';
$config['website_id'] = '';
$config['hash_key'] = '';
<?php

class Plugins_model extends CI_Model 
{
	const MODULE_PATH = 'modules/donate';
	
	public function GetPlugins()
	{
		$plugins = array();
		
		//path to directory to scan
		$directory = "application/" . self::MODULE_PATH . "/";
		
		$i = 0;
		foreach(glob($directory . "plugins/*.json") as $plugin)
		{
			if ($data = file_get_contents($plugin))
			{
				if ($json = json_decode($data, true))
				{
					if (!isset($json['controller']))
						continue;
						
					$plugins[$i]['controller'] = $json['controller'];
					
					// Check if we have a config
					if (isset($json['config']))
					{
						$plugins[$i]['config'] = $this->load->config($json['config'], true);
						
						// If we have a config we might have a enable setting
						if (isset($plugins[$i]['config']['enabled']) && $plugins[$i]['config']['enabled'] != 'true')
						{
							// This payment plugin is not enabled
							unset($plugins[$i]);
						}
					}
				}
			}
			$i++;
		}

		return $plugins;
	}
}

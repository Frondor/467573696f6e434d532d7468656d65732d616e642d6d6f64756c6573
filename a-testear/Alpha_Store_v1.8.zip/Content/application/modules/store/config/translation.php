<?php

$config['lang_realm'] = "Realm";
$config['lang_all_realms'] = "All Realms";
$config['lang_quality'] = "Quality";

$config['lang_pagi_next'] = "Next";
$config['lang_pagi_prev'] = "Prev";
$config['lang_pagi_last'] = "Last";
$config['lang_pagi_first'] = "First";

$config['lang_no_items'] = "No items ware found.";
$config['lang_error_title'] = "An error occured!";
$config['lang_error_headline'] = "Realm not found";
$config['lang_error_text'] = "The selected realm does not exist or is invalid.";
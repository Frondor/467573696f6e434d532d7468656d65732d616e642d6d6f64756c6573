<?php

/*
|--------------------------------------------------------------------------
| General settings
|--------------------------------------------------------------------------
*/

$config['enabled'] = 'true';
$config['button_text'] = 'RentabiliWeb';
$config['rw_iframe_width'] = '705';
$config['rw_iframe_height'] = '520';
$config['document_id'] = '126122';
$config['website_id'] = '414221';
$config['hash_key'] = '433cb7ee1eea70280d491c336175d899d8cef099';
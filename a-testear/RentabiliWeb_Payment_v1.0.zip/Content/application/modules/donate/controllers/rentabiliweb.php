<?php

class Rentabiliweb extends MX_Controller
{
	private $plugins;
	
	const MODULE_PATH = 'modules/donate';
	
	function __construct()
	{
		//Call the constructor of MX_Controller
		parent::__construct();
		
		//Make sure that we are logged in
		$this->user->userArea();

		$this->load->config('donate');
		$this->load->config('rentabiliweb');
		$this->load->model('plugins_model');
		
		// Load the plugins
		$this->plugins = $this->plugins_model->GetPlugins();
	}
	
	public function index()
	{
		requirePermission("view");

		$this->template->setTitle(lang("donate_title", "donate"));

		$user_id = $this->user->getId();
		
		$data = array(
			"donate_paypal" => $this->config->item('donate_paypal'), 
			"donate_paygol" => $this->config->item('donate_paygol'),
			"user_id" => $user_id,
			"server_name" => $this->config->item('server_name'),
			"url" => pageURL,
			"button_text" => $this->config->item('button_text'),
			"document_id" => $this->config->item('document_id'),
			"website_id"  => $this->config->item('website_id'),
			"iframe_width" => $this->config->item('rw_iframe_width'),
			"iframe_height" => $this->config->item('rw_iframe_height'),
			"plugins" => $this->plugins
		);

		$output = $this->template->loadPage("rentabiliweb.tpl", $data);

		$this->template->box("<span style='cursor:pointer;' onClick='window.location=\"".$this->template->page_url."ucp\"'>".lang("ucp")."</span> &rarr; ".lang("donate_panel", "donate"), $output, true, "modules/donate/css/donate.css", "modules/donate/js/donate.js");
	}
}

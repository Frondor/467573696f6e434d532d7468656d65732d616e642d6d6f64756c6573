<?php

class Admin extends MX_Controller
{
	private $PerPage = 10;
	
	public function __construct()
	{
		// Make sure to load the administrator library!
		$this->load->library('administrator');
		$this->load->model('rw_model');
		$this->load->library('pagination');
		
		parent::__construct();
	}

	public function index($page = 0)
	{
		// Change the title
		$this->administrator->setTitle("RentabiliWeb log");
		
		// Get the logs count and logs for the current page
		$TotalLogs 	= $this->rw_model->GetLogsCount();
		$Limit 		= $page . ',' . $this->PerPage;
		$logs 		 = $this->rw_model->getLogs($Limit);
		
		// Generate pagination
		$PaginationConfig['base_url'] = $this->template->page_url . 'rentabiliweb' . '/admin/index/';
		$PaginationConfig['total_rows'] = $TotalLogs;
		$PaginationConfig['per_page'] = $this->PerPage; 
		$PaginationConfig['uri_segment'] = 4;
    	$PaginationConfig["num_links"] = 5;

		$this->pagination->initialize($PaginationConfig); 
		$Pagination = $this->pagination->create_links();
		
		// Free some mem
		unset($PaginationConfig, $Limit, $TotalLogs);
		
		if ($logs)
		{
			foreach($logs as $k => $v)
			{
				$logs[$k]["nickname"] = $this->user->getUsername($v['uid']);
			}
		}
		
		// Prepare my data
		$data = array(
			'logs' => $logs,
			'pagination' => $Pagination,
			'url' => $this->template->page_url
		);

		// Load my view
		$output = $this->template->loadPage("admin.tpl", $data);

		// Put my view in the main box with a headline
		$content = $this->administrator->box('RentabiliWeb log', $output);

		// Output my content. The method accepts the same arguments as template->view
		$this->administrator->view($content, false, "modules/rentabiliweb/js/admin.js");
	}

	public function search()
	{
		$string = $this->input->post('string');
		
		if ($string != '')
		{
			// Try getting a user
			$user_id = (preg_match("/^[a-zA-Z0-9]*$/", $string) && strlen($string) > 3 && strlen($string) < 15) ? $this->user->getId($string) : 0;
			
			// Look for logs
			$results = $this->rw_model->search($string, $user_id);

			if (!$results)
			{
				die("<span>No matches</span>");
			}
		}
		else
		{
			$results = $this->rw_model->getLogs();
		}

		foreach($results as $k => $v)
		{
			$results[$k]["nickname"] = $this->user->getUsername($v['uid']);
		}

		$data = array(
			'url' => $this->template->page_url,
			'results' => $results
		);

		$output = $this->template->loadPage("admin_list.tpl", $data);

		die($output);
	}

	public function give($id = false)
	{
		if (!$id || !is_numeric($id))
		{
			die();
		}

		$log = $this->rw_model->getLogById($id);

		if (!$log)
		{
			die();
		}
		
		$dp = (int)$log['awards'];

		$this->rw_model->giveDp($log['uid'], $dp);

		$data["status"] = 3;

		$this->rw_model->updateLog($id, $data);

		// Add log
		$this->logger->createLog('Manually completed transaction', $id);
	}
}
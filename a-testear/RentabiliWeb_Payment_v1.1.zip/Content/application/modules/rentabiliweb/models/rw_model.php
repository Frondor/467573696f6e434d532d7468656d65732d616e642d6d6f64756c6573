<?php

class Rw_model extends CI_Model 
{
	public function GetLogsCount()
	{
		$query = $this->db->query("SELECT COUNT(*) AS total FROM `rentabiliweb_logs`;");
		
		if ($query && $query->num_rows() > 0)
		{
			$results = $query->result_array();
			
			return (int)$results[0]['total'];
		}
		
		return 0;
	}
	
	public function getLogs($limit = 10)
	{
		$query = $this->db->query("SELECT * FROM `rentabiliweb_logs` ORDER BY `time` DESC LIMIT ".$limit.";");

		if ($query)
		{
			if($query->num_rows() > 0)
			{
				$result = $query->result_array();
				return $result;
			}
			else 
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	public function giveDp($user, $dp)
	{
		$this->db->query("UPDATE `account_data` SET `dp` = dp + ? WHERE `id` = ? LIMIT 1;", array($dp, $user));
	}

	public function search($string, $uid)
	{
		$query = $this->db->query("SELECT * FROM `rentabiliweb_logs` WHERE `uid` = ? OR `trId` LIKE CONCAT('%', ?, '%') OR `message` LIKE CONCAT('%', ?, '%');", array($uid, $string, $string));

		if ($query->num_rows())
		{
			$row = $query->result_array();

			return $row;
		}
		else
		{
			return false;
		}
	}
	
	public function getLogById($id)
	{
		$query = $this->db->query("SELECT * FROM `rentabiliweb_logs` WHERE `id` = ? AND `status` != '1' LIMIT 1;", array($id));

		if ($query->num_rows())
		{
			$row = $query->result_array();

			return $row[0];
		}
		else
		{
			return false;
		}
	}
	
	public function updateLog($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('rentabiliweb_logs', $data);
	}
}
